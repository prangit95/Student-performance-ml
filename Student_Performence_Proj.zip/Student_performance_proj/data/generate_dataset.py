"""
generate_dataset.py
-------------------
Generates a synthetic student performance dataset for demonstration.
In a real project, replace this with your actual data loading logic.
"""

import numpy as np
import pandas as pd

def generate_student_data(n_samples: int = 1287, random_state: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(random_state)

    study_hours     = rng.uniform(1, 40, n_samples).round(1)
    attendance      = rng.uniform(50, 100, n_samples).round(1)
    prev_gpa        = rng.uniform(1.0, 4.0, n_samples).round(2)
    assignments_pct = rng.uniform(0, 100, n_samples).round(1)
    sleep_hours     = rng.uniform(3, 10, n_samples).round(1)
    parent_edu      = rng.integers(1, 5, n_samples)          # 1–4
    internet_access = rng.integers(0, 2, n_samples)          # 0/1
    extracurricular = rng.integers(0, 3, n_samples)          # 0/1/2
    travel_time     = rng.integers(1, 5, n_samples)          # 1–4 (1=<15 min)
    part_time_job   = rng.integers(0, 2, n_samples)          # 0/1
    tutoring        = rng.integers(0, 2, n_samples)          # 0/1
    gender          = rng.integers(0, 2, n_samples)          # 0=F, 1=M
    school_type     = rng.integers(0, 2, n_samples)          # 0=public, 1=private
    peer_group      = rng.integers(1, 4, n_samples)          # 1–3 (academic motivation)
    absences        = rng.integers(0, 20, n_samples)

    # Deterministic score formula with controlled noise
    score = (
        study_hours     * 0.55
        + (attendance - 50) * 0.40
        + (prev_gpa - 1)    * 8.5
        + assignments_pct   * 0.18
        + (sleep_hours >= 6).astype(float) * 5.0
        + parent_edu        * 2.0
        + internet_access   * 3.0
        + extracurricular   * 1.5
        + tutoring          * 4.0
        + peer_group        * 2.0
        - absences          * 1.2
        - travel_time       * 0.5
        - part_time_job     * 2.5
        + rng.normal(0, 5, n_samples)  # realistic noise
    )
    score = np.clip(score, 0, 100).round(2)

    def grade(s):
        if s >= 85: return "Distinction"
        if s >= 70: return "Pass"
        if s >= 50: return "Average"
        return "Fail"

    df = pd.DataFrame({
        "study_hours":      study_hours,
        "attendance_pct":   attendance,
        "prev_gpa":         prev_gpa,
        "assignments_pct":  assignments_pct,
        "sleep_hours":      sleep_hours,
        "parent_edu":       parent_edu,
        "internet_access":  internet_access,
        "extracurricular":  extracurricular,
        "travel_time":      travel_time,
        "part_time_job":    part_time_job,
        "tutoring":         tutoring,
        "gender":           gender,
        "school_type":      school_type,
        "peer_group":       peer_group,
        "absences":         absences,
        "score":            score,
        "grade":            [grade(s) for s in score],
    })
    return df


if __name__ == "__main__":
    df = generate_student_data()
    df.to_csv("student_data.csv", index=False)
    print(f"Dataset saved → student_data.csv  ({len(df)} rows, {df.shape[1]} columns)")
    print(df["grade"].value_counts())
